//#1
var num1 = 0;
var num2 = 2;
var num3 = 0;
var num4 = 2;

console.log(num1 / num2)

var str1 = "This is my first \"ever\" string";

console.log(str1);

var myVar = 0;
var myVar = true;
var myVar = null;
var myVar = undefined;
var myVar = "Edgar";

var animal = {
    type: "tiger",
    name: "tony",
    color: "orange",
    weight: 300,
    diet: "carne",
    var activities = new Array("running", "hunting", "playing");
  
};

console.log(animal);